<?php
session_start();

if ( !empty($_POST) ) {

	if ( isset($_POST['getcaptchas']) ) {

		$bilder = array(

			array(	'bild' => 'der-verlorene-sohn.jpg',
					'frage' => 'Wie viele Personen sind auf dem Bild?',
					'antwort' => 5 ),
					
			array(	'bild' => 'die-anatomie.jpg',
					'frage' => 'Wie viele Leichen sind auf dem Bild?',
					'antwort' => 1 ),
					
			array(	'bild' => 'die-badenden.jpg',
					'frage' => 'Wie viele Personen sind auf dem Bild?',
					'antwort' => 7 ),
					
			array(	'bild' => 'die-judenbraut.jpg',
					'frage' => 'Wie viele Personen sind auf dem Bild?',
					'antwort' => 2 ),
					
			array(	'bild' => 'die-vorsteher.jpg',
					'frage' => 'Wie viele Personen tragen einen hohen, spitzen Hut??',
					'antwort' => 4 ),
					
			array(	'bild' => 'las-meninas.jpg',
					'frage' => 'Wie viele Personen sind auf dem Bild?',
					'antwort' => 5 ),
					
			array(	'bild' => 'last-supper.jpg',
					'frage' => 'Wie viele Frauen sind auf dem Bild?',
					'antwort' => 0 ),
					
			array(	'bild' => 'nicolas-poussin.jpg',
					'frage' => 'Wie viele Frauen sind auf dem Bild?',
					'antwort' => 1 )
					
		);

		$caps = array();

		while ( count($caps) != 3 ) {
			$random = rand(0,count($bilder)-1);
			if ( !in_array ($random,$caps) ) {
				$caps[] = $random;
			}
		}

		$captchas = array();
		
		$i=0;
		foreach ($caps as $key => $value ) {
			$_SESSION['answers'][$i] = $bilder[$value]['antwort'];
			unset($bilder[$value]['antwort']);
			$captchas[] = $bilder[$value];
			$i++;
		}
		
		$_SESSION['retries'] = 0;
		$capson = json_encode($captchas);
		echo $capson;
		
#######################################################################
#
# CHECK ANSWERS
#		
	} elseif ( isset($_POST['check']) && isset($_POST['answer'])  ) {
		$id = trim( filter_input(INPUT_POST,'check',FILTER_SANITIZE_STRING) );
		$answer = trim( filter_input(INPUT_POST,'answer',FILTER_SANITIZE_STRING) );

		$_SESSION['retries']++;
		
		// for ( $i=0; $i<3; $i++) {
			// echo $i. ' ' .$_SESSION['answers'][$i].'<br>';
		// }
		if ($_SESSION['retries'] < 10) {
			if ( isset($_SESSION['answers'][$id]) && $_SESSION['answers'][$id] == $answer ) {
				echo 'true';
			} else {
				echo 'false';
			}
		} else {
			session_destroy();
			echo 'reload';
		}
	
	
	}

###################################################################
# end of $_POST-check

}
	

?>