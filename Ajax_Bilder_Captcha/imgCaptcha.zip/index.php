<!DOCTYPE html>
<html lang="DE">
<head>
<title>Ajax Captcha</title>

<style>
* { font-family: Tahoma; font-size: 12pt; }
label { display: inline-block; width: 100px; text-align: right; }

#wrapper { width: 60%; margin: auto; border: 1px solid #eee; margin: 10px; padding: 10px; }
#anzeige { width: 90%; margin: auto; border: 1px solid #eef; margin: 10px; min-height: 30px; font-size: 12pt; }
#phpimage { margin-left: 105px; border: 1px solid blue; padding: 3px; }


#finalDiv {
	font-size: 20pt; 
	font-weight: bold;
	font-family: Times, Times New Roman, serif;
	font-style: italic;
	
}
#finalDiv span {
	font-family: Courier, Courier New, monospace;
	font-size: 10pt;
	font-style: normal;
}



.captcha {
	display: inline-block;
	width: 200px;
	text-align: center;
	padding: 10px;	
}

.captcha img {
	max-width: 180px;
	max-height: 150px;
	height: auto;
	width: auto;
}

.captcha div {
	font-size: 11pt;
	margin: 5px 0;
}



</style>
</head>

<body>

<h3><a href="index.php">Ajax Captcha 2</a></h3>


<div id="wrapper">

<div id="anzeige"><strong>Beantworte die Fragen:</strong><br />(max. 10 Versuche)</div>


</div>



<script>


var wrapper = document.getElementById('wrapper');
var anzeige = document.getElementById('anzeige');
var capimg = 'capimg/';	// Bilderordner!
var correctAnswers = ['false','false','false'];

var xhr = new XMLHttpRequest();



getCaptchas();



function getCaptchas() {
	
	xhr.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
	
			 // alert(this.responseText);
			var obj = JSON.parse(this.responseText);
			
			var i = 0;
			for (var element in obj) {
				var myCaptchaDiv = document.createElement('div');
				myCaptchaDiv.setAttribute('class','captcha');
				myCaptchaDiv.setAttribute('id','captcha'+i);
				
				var myCaptchaImg = document.createElement('img');
				myCaptchaImg.setAttribute('src',capimg+obj[element].bild);
				myCaptchaDiv.appendChild(myCaptchaImg);
				
				var myQuestionDiv = document.createElement('div');
				myQuestionDiv.innerText = obj[element].frage;
				myCaptchaDiv.appendChild(myQuestionDiv);
				
				var myAnswer = document.createElement('select');
				myAnswer.setAttribute('id','answer'+i);
				var objectX = document.createElement('option');
					objectX.value = '';
					objectX.text = '?';
				myAnswer.appendChild(objectX);
				for (var y=0; y < 10; y++) {
					var object = document.createElement('option');
					object.value = y;
					object.text = y;
					myAnswer.appendChild(object);
				}
				
				var myResult = document.createElement('div');
				myResult.setAttribute('id','result'+i);
				myResult.innerHTML = '&nbsp;';

				myAnswer.onchange = function() {
					checkAnswer(this.id,this.value);
				};

				
				myCaptchaDiv.appendChild(myAnswer);
				myCaptchaDiv.appendChild(myResult);
				wrapper.appendChild(myCaptchaDiv);
				i++;
			}
			
		}
	};	
	
	
	xhr.open("POST","imgcaptcha.php");
	xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhr.send('getcaptchas=nada'); // dummy to enforce request!
}





function checkAnswer(idFull,value) {
	var answer = value;
	var id = idFull.replace('answer','');
	
	var searchString = 'check='+id+'&answer='+answer;
	
	xhr.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			var response = this.responseText;
			if (response != 'reload') {
				var dummyString = 'result'+id;
				var ausgabe = document.getElementById(dummyString);
				var text = response.replace('true','ok!');			
				var text = text.replace('false','falsch!');			
				
				ausgabe.innerText = text;
				correctAnswers[id] = response;
				
				var check = testAllAnswers();
				if (check == 'true') {
					doTheJob();
				}
			} else {
				xhr.abort();
				window.location.reload(true);
			}
		}
	};
		
	xhr.open("POST","imgcaptcha.php");
	xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhr.send(searchString); // dummy to enforce request!
}



function testAllAnswers() {
	var check = 'true';
	for ( var i=0; i<3; i++ ) {
		if ( correctAnswers[i] == 'false' ) {
			check = 'false';
		}
	}
	
	return check;	
}


function doTheJob() {
	for (var i=0;i<3;i++) {
		var dummy = document.getElementById('captcha'+i);
		dummy.parentNode.removeChild(dummy);
	} 
	
	var finish = document.createElement('div');
	finish.setAttribute('id','finalDiv');
	finish.innerHTML = 'What had to be done - has been done.<br>You may proceed!<br><br><br><br><br><span>(A note to the Admin: Do something useful here....)</span>';
	wrapper.appendChild(finish);
}





	
</script>




</body>
</html>