<?php
session_start();

if ( isset($_SESSION['captcha']) && isset( $_POST['test'] ) ) {

	$original = trim( $_SESSION['captcha'] );
	$test = trim ( filter_input(INPUT_POST,'test',FILTER_SANITIZE_STRING) );
	
	if ( $test == $original) {
		$_SESSION['trycount'] = 0;
		echo "1";
	} else {

		if ( !isset( $_SESSION['trycount'] ) || $_SESSION['trycount'] == 0 ) {
			$x = 1;
			$_SESSION['trycount'] = $x;
			echo '0';
		} elseif ( $_SESSION['trycount'] == 3 ) {
			echo '2'; 
		} else {
			$x = $_SESSION['trycount'];
			$x++;
			if ($x > 3) {
				$x = 3;
			}
			$_SESSION['trycount'] = $x;
			echo '0';
		}
		
	}
	
} else {
	$_SESSION['trycount'] = '0';
	echo "da fehlt wat!";
}
?>